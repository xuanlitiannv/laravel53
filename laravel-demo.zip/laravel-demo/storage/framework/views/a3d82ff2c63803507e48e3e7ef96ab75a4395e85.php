<form class="form-horizontal" method="post" action="">
    <!--生成一个隐藏的input表单 任何指向 web 中 POST, PUT 或 DELETE 路由的 HTML 表单请求都应该包含一个 CSRF 令牌，否则，这个请求将会被拒绝。-->
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="name" class="col-sm-2 control-label">姓名</label>
        <div class="col-sm-5">
        <!--name对应模板中的key  数据保持<?php echo e(old('Student')['name']); ?> 为了让数据显示在修改的框中<?php echo e(old('Student')['name']?old('Student')['name']:$student->name); ?>create和update都有返回参数student
                比如添加的时候刚进入页面没有数据则显示student->name 添加一部分数据不全就提交的时候走old,修改的时候走的old-->
            <input type="text" name="Student[name]" class="form-control" id="name"  value="<?php echo e(old('Student')['name']?old('Student')['name']:$student->name); ?>" placeholder="请输入学生姓名">
        </div>
        <div class="col-sm-5">
            <p class="form-control-static text-danger"><?php echo e($errors->first('Student.name')); ?></p>
        </div>
    </div>
    <div class="form-group">
        <label for="age" class="col-sm-2 control-label">年龄</label>
        <div class="col-sm-5">
            <input type="text" name="Student[age]" class="form-control" id="age" value="<?php echo e(old('Student')['age']?old('Student')['age']:$student->age); ?>" placeholder="请输入学生年龄">
        </div>
        <div class="col-sm-5">
            <p class="form-control-static text-danger"><?php echo e($errors->first('Student.age')); ?></p>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">性别</label>
        <div class="col-sm-5">
            <!--$student->sex()返回一个数组 isset()判断属性是否存在-->
            <?php foreach($student->sex()as $ind=>$val): ?>
                <label class="radio-inline">
                    <input type="radio" name="Student[sex]"
                           <?php echo e(isset($student->sex)&&$student->sex == $ind ? 'checked':''); ?>

                           value="<?php echo e($ind); ?>"><?php echo e($val); ?>

                </label>
            <?php endforeach; ?>
        </div>
        <div class="col-sm-5">
            <p class="form-control-static text-danger"><?php echo e($errors->first('Student.sex')); ?></p>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">提交</button>
        </div>
    </div>
</form>