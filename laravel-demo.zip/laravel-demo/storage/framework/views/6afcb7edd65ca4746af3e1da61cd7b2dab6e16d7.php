<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--自定义内容区域-->
    <div class="panel panel-default">
        <div class="panel-heading">学生列表</div>
        <table class="table table-striped table-hover table-responsive">
            <thead>
            <tr>
                <th>ID</th>
                <th>姓名</th>
                <th>年龄</th>
                <th>性别</th>
                <th>添加时间</th>
                <th width="120">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($students as $student): ?>
            <tr>
                <th scope="row"><?php echo e($student->id); ?></th>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->age); ?></td>
                <!--sex方法（数据库中sex的数值） 切记数据库中不能包含空的字符串，他是int型-->
                <td><?php echo e($student->sex($student->sex)); ?></td>
                <td><?php echo e(date('Y-m-d',$student->created_at)); ?></td>
                <td>
                    <a href="<?php echo e(url('student/detail',['id'=>$student['id']])); ?>">详情</a>
                    <a href="<?php echo e(url('student/update',['id'=>$student->id])); ?>">修改</a>
                    <a href="<?php echo e(url('student/delete',['id'=>$student->id])); ?>"
                       onclick="if(confirm('确定要删除数据么？')==false) return false;">删除</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <!--分页-->
    <div>
        <div class="pull-right">
            <?php echo e($students->render()); ?>

        </div>
        <?php /*<ul class="pagination pull-right">*/ ?>
            <?php /*<li>*/ ?>
                <?php /*<a href="#" aria-label="Previous">*/ ?>
                    <?php /*<span aria-hidden="true">&laquo;</span>*/ ?>
                <?php /*</a>*/ ?>
            <?php /*</li>*/ ?>
            <?php /*<li class="active"><a href="#">1</a></li>*/ ?>
            <?php /*<li><a href="#">2</a></li>*/ ?>
            <?php /*<li><a href="#">3</a></li>*/ ?>
            <?php /*<li><a href="#">4</a></li>*/ ?>
            <?php /*<li><a href="#">5</a></li>*/ ?>
            <?php /*<li>*/ ?>
                <?php /*<a href="#" aria-label="Next">*/ ?>
                    <?php /*<span aria-hidden="true">&laquo;</span>*/ ?>
                <?php /*</a>*/ ?>
            <?php /*</li>*/ ?>
        <?php /*</ul>*/ ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>