<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.validator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="panel panel-default">
        <div class="panel-heading">新增学生</div>
        <div class="panel-body">
            <!--新增有两种方式实现，一种模型新增 action="<?php echo e(url('student/save')); ?>，一种是create新增action=""-->
                <?php echo $__env->make('common._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>