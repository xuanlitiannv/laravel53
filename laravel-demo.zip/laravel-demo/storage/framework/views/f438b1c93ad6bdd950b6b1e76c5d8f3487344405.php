<!--错误信息kernel 中ShareErrorsFromSession 中的errors反馈到view中-->
<?php if(count($errors)): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo e($errors->first()); ?></li>
        </ul>
    </div>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>