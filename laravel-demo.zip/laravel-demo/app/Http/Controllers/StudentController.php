<?php
/**
 * Created by PhpStorm.
 * User: 宋若仙
 * Date: 2018-04-05
 * Time: 23:03
 */
namespace App\Http\Controllers;

use App\Models\Student;
use Dotenv\Validator;
use Illuminate\Http\Request;

class StudentController extends Controller{
    //学生列表页
    public function index()
    {
        $students=Student::paginate(2);
        return view('student.index',[
            'students'=>$students
        ]);
    }

    //直接通过create方法新增
    public function create(Request $request){
        //模型新增（为了性别传参）
        $student=new Student();
        if($request->isMethod('POST')){

            //1.控制器验证(common/validator.blade.php + create.blade.php(@include('common.validator'))
            //错误信息kernel 中ShareErrorsFromSession 中的errors反馈到view中
            //自定义错误信息
//            $this->validate($request,[
//               'Student.name'=>'required|min:2|max:20',
//               'Student.age'=>'required|integer',
//               'Student.sex'=>'required|integer',
//            ],[
//                'required'=>':attribute 为必填项',
//                'min'=>':attirbute 长度不符合要求',
//                'integer'=>':attribute 必须为整数'
//            ],[
//                'Student.name'=>'姓名',
//                'Student.age'=>'年龄',
//                'Student.sex'=>'性别',
//            ]);
            //2/Validator类验证 全局的
            $validator=\Validator::make($request->input(),[
               'Student.name'=>'required|min:2|max:20',
               'Student.age'=>'required|integer',
               'Student.sex'=>'required|integer',
            ],[
                'required'=>':attribute 为必填项',
                'min'=>':attirbute 长度不符合要求',
                'integer'=>':attribute 必须为整数'
            ],[
                'Student.name'=>'姓名',
                'Student.age'=>'年龄',
                'Student.sex'=>'性别',
            ]);
            if($validator->fails()){
                //注册错误信息withErrors($validator)
                //数据保持withInput()(默认把request全传进去了)+create.blade.php中value={{old(Student)['name']}}Student数组下的name字段
                return redirect()->back()->withErrors($validator)->withInput();
            }



           //直接通过create方法新增(create.blade.php)
            $data=$request->input('Student');
            if(Student::create($data)){
                return redirect('student/index')->with('success','操作成功提示');
            }else{
                return redirect()->back()->with('error','操作失败提示');
            }
        }
        return view('student.create',[
            'student'=>$student
        ]);

    }
    //修改信息Request $request作为第一个参数，不会影响路由
    public function update(Request $request,$id){
        $student= Student::find($id);
        if($request->isMethod('POST')){

            //2/Validator类验证 全局的
            $validator=\Validator::make($request->input(),[
                'Student.name'=>'required|min:2|max:20',
                'Student.age'=>'required|integer',
                'Student.sex'=>'required|integer',
            ],[
                'required'=>':attribute 为必填项',
                'min'=>':attirbute 长度不符合要求',
                'integer'=>':attribute 必须为整数'
            ],[
                'Student.name'=>'姓名',
                'Student.age'=>'年龄',
                'Student.sex'=>'性别',
            ]);
            if($validator->fails()){
                //注册错误信息withErrors($validator)
                //数据保持withInput()(默认把request全传进去了)+create.blade.php中value={{old(Student)['name']}}Student数组下的name字段
                return redirect()->back()->withErrors($validator)->withInput();
            }


            //取到以name为Student为底的数据
            $data = $request->input('Student');
            //获取数据库中字段的属性（通过模型方式）$student->
            $student->name=$data['name'];
            $student->age=$data['age'];
            $student->sex=$data['sex'];
            if($student->save()){
                return redirect('student/index')->with('success','修改成功-'.$id);
            }
        }

        return view('student.update',[
            'student'=>$student
        ]);
    }
    //信息详情
    public function detail($id){
        $student =Student::find($id);
        return view('student.detail',[
            'student'=>$student
        ]);
    }
    //删除
    public function delete($id){
       $student=Student::find($id);
       if($student->delete()){
           return redirect('student/index')->with('success','删除成功');
       }else{
           return redirect('student/index')->with('error','删除失败');
       }
    }

    //模型新增的create的状态，与save()方法共存
//    public function create(){
//        return view('student.create');
//    }

    //保存添加
//    public function save(Request $request){
//        //获取name中以Student作为下标的值
//        $data=$request->input('Student');
////        var_dump($data);
//        //通过模型新增
//        $student=new Student();
//        $student->name=$data['name'];
//        $student->age=$data['age'];
//        $student->sex=$data['sex'];
//        if($student->save()){
//            return redirect('student/index');
//       }else{
//           return redirect()->back();
//        }
//
//    }

}