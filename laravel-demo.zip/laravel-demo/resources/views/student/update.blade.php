@extends('common.layout')
@section('content')
    @include('common.validator')
    <div class="panel panel-default">
        <div class="panel-heading">修改学生</div>
        <div class="panel-body">
        <!--新增有两种方式实现，一种模型新增 action="{{url('student/save')}}，一种是create新增action=""-->
            @include('common._form')
        </div>
    </div>
@stop